clc
close all
clear all

fs=30;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)



for n=3:20
    tmp(n)=2*sqrt(n^2/9-1)+(2*n-1)/3;
end

m=4; n=3;
J=1;
V=2*sqrt(m^2/9-1)+(2*m-1-4*n)/3;
U=-4*sqrt(m^2/9-1)+V;
H = [V             -sqrt(2)*J     -sqrt(2)*J; 
     -sqrt(2)*J        U                0;
     -sqrt(2)*J        0                U    ];
 
psi=[1,0,0]';
Uevolve=expm(-1i*H*0.01);

totaltime=3*pi/2*100;
for i=1:totaltime   
    psi=Uevolve*psi;
    realpart(i)=real(psi(1));
    imagpart(i)=imag(psi(1));
end

x=1:totaltime;
figure(1)
theta = linspace(0, 2*pi, 1000);
x_unit_circle = cos(theta); 
y_unit_circle = sin(theta); 
plot(x_unit_circle, y_unit_circle, 'k--'); 
hold on
plot(realpart, imagpart, 'r', 'MarkerSize', 3); 
plot(real(realpart(1)), imagpart(1), 'go', 'MarkerSize', 5, 'LineWidth', 3, 'MarkerFaceColor', 'g');
plot(real(realpart(end)), imagpart(end), 'bo', 'MarkerSize', 5, 'LineWidth', 3,'MarkerFaceColor', 'b');
axis equal; 
%grid off; 
xlabel('Real axis'); 
ylabel('Imag. axis'); 
legend('Unit circle', 'Trajectory', 'Location', 'northeast','FontSize',24);

xlim([-1.3, 1.3]);
ylim([-1, 1]);
title('Back to $\left|0;0\right>_L$','Interpreter', 'latex')
 saveas(gcf,'evolution_SWAP1.eps','epsc'); 
 
% 1001, 0011, 0110, 1100

H2=[0 -1 0 -1; -1 0 -1 0; 0 -1 0 -1; -1 0 -1 0];
%H2=[0 -1;-1 0];
psi1=[1,0,0,0]';

U2=expm(-1i*H2*0.0001);
totaltime2=pi/2*10000;
for i=1:totaltime2
     psi1=U2*psi1;
     P1(i)=psi1(1)*psi1(1)';
     P2(i)=psi1(2)*psi1(2)';
     P3(i)=psi1(3)*psi1(3)';
     P4(i)=psi1(4)*psi1(4)';
end
x2=1:totaltime2;
x2=x2/totaltime2;
figure(2)
plot(x2,P1,'r')
hold on
plot(x2,P3,'b')
plot(x2,P2,'g')
plot(x2,P4,'k--')
box on
xlabel('$t/T_{\rm S}$','Interpreter', 'latex'); 
ylabel('Population'); 
legend('$\left|0;1\right>_L$', '$\left|1;0\right>_L$','$\left|00;11\right>$','$\left|11;00\right>$','Interpreter', 'latex', 'Location', 'northeast','FontSize',24);
title('$\left|0;1\right>_L$ swaps to $\left|1;0\right>_L$','Interpreter', 'latex')
saveas(gcf,'evolution_SWAP2.eps','epsc'); 