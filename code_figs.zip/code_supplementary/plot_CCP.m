fs=28;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman' )
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)

m1=5:30;
i=1:201;
pcolor(m1,tmp,log10(abs(phi111(m1,:)')));
shading flat
hold on
peakfunction=[0.99,0.99];
[M0,c]=contour(m1,tmp,F(m1,:)',peakfunction,'LineStyle','--','LineColor','k','ShowText','on');
c.LineWidth = 2;
clabel(M0,c,'FontSize',fs,'Color','black','labelspacing',800,'Margin',4);

xlabel('$m$','FontSize',fs,'interpreter','latex');
ylabel('$V_2/J$','interpreter','latex');

hh=colorbar; colormap(turbo);
ylabel(hh,'Log$_{10}|\varphi_{111}/\pi|$','interpreter','latex');
caxis([-3 0])
saveas(gcf,'CCP','epsc')