clc
close all
clear all

fs=30;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)
% V=0.5;
% U=-2.5;
% J=-1;
V=-(3.5-2*sqrt(3));
%U0=3.5-6*sqrt(3);
U0=-(3.5+2*sqrt(3));
J=1;

H = [V             -sqrt(2)*J     -sqrt(2)*J; 
     -sqrt(2)*J        U0                0;
     -sqrt(2)*J        0                U0    ];

[S,E]=eig(H); 
total_time = abs(2*pi/J);

psi= [1; 0; 0];

num_steps = 100000;

dt=total_time/num_steps;
U=expm(-1i * H * dt); 
%psi_t = zeros(3, num_steps);
for step=1:num_steps    
    psi=U*psi;
    coeff(step)=psi(1);
end
realPart = real(coeff);
imagPart = imag(coeff);

figure(1)
theta = linspace(0, 2*pi, 1000);
x_unit_circle = cos(theta); 
y_unit_circle = sin(theta); 
plot(x_unit_circle, y_unit_circle, 'k--'); 
hold on
plot(real(realPart(1:end-1)), imagPart(1:end-1), 'r', 'MarkerSize', 3); 
plot(real(realPart(1)), imagPart(1), 'go', 'MarkerSize', 5, 'LineWidth', 3, 'MarkerFaceColor', 'g');
plot(real(realPart(end)), imagPart(end), 'bo', 'MarkerSize', 5, 'LineWidth', 3,'MarkerFaceColor', 'b');
axis equal; 
grid off; 
xlabel('Real axis'); 
ylabel('Imag. axis'); 
legend('Unit circle', 'Trajectory', 'Location', 'northeast');
legend('boxon'); 
xlim([-1.3, 1.3]);
ylim([-1, 1]);
 saveas(gcf,'evolution_CZ.eps','epsc');

figure(2)
phases=angle(coeff)/pi;
index=find(phases>0.5);
phases(index)=phases(index)-2;
x=linspace(0, total_time/(2*pi), num_steps);
% plot(x(1:index(1)-1),phases(1:index(1)-1), 'b-'); 
% hold on
% plot(x(index(1):end), phases(index(1):end), 'b-'); 
 plot(x, phases, 'b-'); 
 hold on
 plot(x(end),phases(end),'bo', 'MarkerSize', 5, 'LineWidth', 3,'MarkerFaceColor', 'b');
xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');
ylabel('Phase ($\pi$)', 'Interpreter', 'latex');
grid off;
xticks([0, 0.25, 0.5, 0.75, 1]);
xticklabels({'0', '0.25', '0.5', '0.75', '1'});
yticks([-1, -0.5, 0, 0.5,1]); 
yticklabels({'-1', '-0.5', '0','0.5', '1'});
ylim([-1,0])
 saveas(gcf,'phase_CZ.eps','epsc');
% complexNumbers = psi_t(1,:);
% realPart = real(complexNumbers);
% imagPart = imag(complexNumbers);
% figure(1)
% theta = linspace(0, 2*pi, 1000);
% x_unit_circle = cos(theta); 
% y_unit_circle = sin(theta); 
% plot(x_unit_circle, y_unit_circle, 'k--'); 
% hold on; 
% plot(real(realPart(1:end-1)), imagPart(1:end-1), 'r', 'MarkerSize', 3); 
% plot(real(realPart(1)), imagPart(1), 'go', 'MarkerSize', 5, 'LineWidth', 3, 'MarkerFaceColor', 'g');
% plot(real(realPart(end)), imagPart(end), 'bo', 'MarkerSize', 5, 'LineWidth', 3,'MarkerFaceColor', 'b');
% axis equal; 
% grid off; 
% xlabel('Real axis'); 
% ylabel('Imag. axis'); 
% legend('Unit circle', 'Trajectory', 'Location', 'southeast');
% legend('boxon'); 
% xlim([-1, 1]);
% ylim([-1, 1]);
% width = 350;  
% height = 350; 
% set(gcf, 'Position', [100, 100, width, height]);
% saveas(gcf,'evolution_CZ.eps','epsc');
% hold off; 



% complex_matrix = psi_t(1,:);
% angles = angle(complex_matrix);
% figure(2)
% plot(linspace(0, total_time/(2*pi), num_steps-1), angles(1:end-1)/pi, 'black-'); 
% xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');
% ylabel('Phase ($\pi$)', 'Interpreter', 'latex');
% grid off;
% xticks([0, 0.25, 0.5, 0.75, 1]);
% xticklabels({'0', '0.25', '0.5', '0.75', '1'});
% yticks([-1, -0.5, 0, 0.5,1]); 
% yticklabels({'-1', '-0.5', '0','0.5', '1'});


% yticks([-pi, -0.5*pi, 0, 0.5*pi,pi]); 
% yticklabels({'-π', '-0.5π', '0','0.5π', 'π'});