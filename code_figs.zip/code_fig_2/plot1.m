clc
close all
clear all
fs=30;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)

V=-0.036;
J=1;
U=-6.964;
H = [0 -J; -J 0];

total_time = abs(2*pi/J);

psi_0 = [1; 0];

num_steps = 10000;
dt=total_time/num_steps;

psi_t = zeros(2, num_steps);

for step = 1:num_steps
    
    psi_t(:, step) = expm(-1i * H * dt * step ) * psi_0;
end


figure;
plot(linspace(0, total_time, num_steps)/(2*pi), abs(psi_t(1, :)).^2, 'r', 'LineWidth', 2);
hold on;
plot(linspace(0, total_time, num_steps)/(2*pi), abs(psi_t(2, :)).^2, 'b', 'LineWidth', 2);
xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');
ylabel('Population');
%legend({'$|1001\rangle$', '$|1100\rangle$'}, 'Interpreter', 'latex');
legend({'$\left|0;1\right>_L$', '$\left|11;00\right>$'}, 'Interpreter', 'latex');
xticks([0, 0.25, 0.5, 0.75, 1]);
xticklabels({'0', '0.25', '0.5', '0.75', '1'});
%legend('boxon'); 
%grid off;

saveas(gcf,'evolution1.eps','epsc');