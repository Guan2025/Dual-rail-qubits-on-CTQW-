clc
close all
clear all

fs=30;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)

V=-0.036;
J=1;
U=-6.964;
% 定义3x3哈密顿量矩阵
H = [V             -sqrt(2)*J     -sqrt(2)*J; 
     -sqrt(2)*J        U                0;
     -sqrt(2)*J        0                U    ];

total_time = abs(2*pi/J);

psi_0 = [1; 0; 0];

num_steps = 1000;

dt=total_time/num_steps;

psi_t = zeros(3, num_steps);

for step = 1:num_steps
   
    psi_t(:, step) = expm(-1i * H * dt * step) * psi_0;
end

figure;
plot(linspace(0, total_time/(2*pi), num_steps), abs(psi_t(1, :)).^2,'r', 'LineWidth', 2);
hold on;
plot(linspace(0, total_time/(2*pi), num_steps), abs(psi_t(2, :)).^2,'b', 'LineWidth', 2);
plot(linspace(0, total_time/(2*pi), num_steps), abs(psi_t(3, :)).^2, '--g', 'LineWidth', 2);
xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');ylabel('Population');
%legend({'$\color{red}|0101\rangle$', '$|0200\rangle$', '$|0002\rangle$'}, 'Interpreter', 'latex');
legend({'$\left| 1;1 \right>_L$ ', '$\left| 02;00 \right>$', '$\left| 00;02 \right>$'}, 'Interpreter', 'latex'); 
title('');
grid off;
xticks([0, 0.25, 0.5, 0.75, 1]);
xticklabels({'0', '0.25', '0.5', '0.75', '1'});
ylim([0,1]);
legend('boxon'); 
saveas(gcf,'evolution2.eps','epsc');