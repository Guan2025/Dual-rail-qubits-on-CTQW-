clear all
close all
fs=30;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)

steps=501;

U=-3.5-2*sqrt(3);
V0=-3.5+2*sqrt(3);

deltaV=0.02/(steps-1);
V=V0-0.01:deltaV:V0+0.01;
for i=1:steps
    deltaJ(i)=0.99+(i-1)/(steps-1)*0.02;
    J=deltaJ(i);
    J2=-sqrt(2)*J;
    H_2=[0 -J;-J 0];
    Utmp=expm(-1i*H_2*2*pi);
    c2=Utmp(1,1);
    c3=c2;
    for j=1:steps
%         deltaV(j)=-0.505+(j-1)/(steps-1)*0.01;
%         V=deltaV(j);
        
        H_3=[V(j),J2,J2;J2,U,0;J2,0,U];
        Utmp=expm(-1i*H_3*2*pi);
        c4=Utmp(1,1);
        M=diag([1,c2,c3,-c4]);
        
         F(i,j) =1/20*(trace(M*M')+abs(trace(M))^2);
        
        
    end
end
color_hot=colormap(jet);%颜色图的提取
mycolor=[color_hot(:,3),color_hot(:,2),color_hot(:,1)];%也可以用fliplr()函数，交换红蓝颜色通道
%hs=contourf(deltaJ,-2*deltaV,1-F, 'LineColor', 'none');
hs=pcolor(deltaJ,V/abs(V0),1-F');
% yticks([0.99 1 1.01])
% yticklabels({'0.99','1','1.01'})
colormap(mycolor);
cbar=colorbar;
%shading interp;
set(gca,'ColorScale','log');
set(gca,'tickdir','out')
caxis([1E-5 1E-3]);
cbar.Ticks = [1E-5 1E-4 1E-3];

%xlabel('$J/J_{\rm CP}$','Interpreter','latex');
%ylabel('$V/V_{\rm CP}$','Interpreter','latex');
%title('Infidelity');
set(hs,'EdgeALpha','0'); % 去掉pcolor网格
print('-depsc2', '.\fidelity_color_inset.eps'); 