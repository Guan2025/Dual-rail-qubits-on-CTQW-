clc
close all
clear all

fs=24;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)

delta=-0.1:0.0001:0.1;
V=-(3.5-2*sqrt(3));
%U0=3.5-6*sqrt(3);
U0=-(3.5+2*sqrt(3));
J=1;

H0 = [V             -sqrt(2)*J     -sqrt(2)*J; 
     -sqrt(2)*J        U0                0;
     -sqrt(2)*J        0                U0    ];
for i=1:2001

H_2=[delta(i) -1;-1 0];
U=expm(-1i*H_2*2*pi);
c2=U(1,1);

H_3=[0 -1;-1 delta(i)];
U=expm(-1i*H_3*2*pi);
c3=U(1,1);
    
%H0=[-1/2,-sqrt(2),-sqrt(2);-sqrt(2),5/2,0;-sqrt(2),0,5/2];

V=delta(i)*diag([1,0,2]);
H=H0+V;
U=expm(-1i*H*2*pi);
c4=U(1,1);

U=diag([1,c2,c3,c4]);
U_CZ=diag([1,1,1,-1]);
M=U_CZ'*U;
F(i)=1/20*(trace(M*M')+abs(trace(M))^2);
P(i)=1/4*trace(M*M');
%P(i)=(1+c2*c2'+c3*c3'+c4*c4')/4;
L(i)=1-P(i);
end

%F2=1+1/20*(234/125-8*pi^2)*delta.^2;
F2=1-2/5*pi^2*delta.^2+1/10*real(exp(-1i*4*sqrt(3)*pi))*delta.^2;
P2=1+1/8*cos(4*sqrt(3)*pi)*delta.^2+1/64*delta.^4;
L_pert=1-P2;
%figure
fig = figure;
left_color = [0 0 1];
right_color = [1 0 0];
set(fig,'defaultAxesColorOrder',[left_color; right_color]);

yyaxis left
h1=plot(delta,1-F,'b')
hold on
x=1:50:2001;
h2=plot(delta(x),1-F2(x),'bs','MarkerSize',8)
ylabel('Infidelity')


yyaxis right
h3=plot(delta,L,'r')
hold on
x=1:50:2001;
h4=plot(delta(x),2*L_pert(x),'ro')
ylabel('Leakage')
xlabel('$\Delta/J_{\rm CP}$','Interpreter','latex')


%leg1.TextColor = 'k';

% axes('Position', [0.45 0.55 0.25 0.25]); 
% %figure(2)
% x=delta(1002:2001);
% loglog(x,L((1002:2001)),'r')
% yticks([1E-15 1E-10 1E-5])
% box on
% set(gca,'tickdir','in')
% hold on
% 
% x2=log10(x);
% L2=log10(L(1002:2001));
% model=fittype('a*x+b');
% fitresult=fit(x2',L2',model)
% b=fitresult.b;
% a=fitresult.a;
% y2=10^b*x.^a;
% t=1:50:1000;
% h4=loglog(x(t),y2(t),'g--','MarkerSize',5)
% box on
% set(gca,'FontName','Times New Roman','FontSize',18);
% ylabel('Leakage')

h=[h1,h2,h3,h4]
leg1=legend(h,'Numerical, IF','Perturb, IF','Numerical, L','Perturb, L','location','northeast','FontSize',18)

saveas(gcf,'gate_fidelity.eps','epsc');