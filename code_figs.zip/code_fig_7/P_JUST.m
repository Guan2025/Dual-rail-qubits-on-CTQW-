function M = P_JUST(A,B)
    N = length(A);
    AT = zeros(N,1);
    BT = AT.'*0;
    M = zeros(N^2,N^2);
    for ni = 1:N^2
        m = mod(ni-1,N)+1;
        n = (ni-m)/N+1;
        AT(:,1) = A(m,:);
        BT(1,:) = B(:,n);
        MT = AT*(BT);
        M(ni,:) = MT(1:end);
    end
end