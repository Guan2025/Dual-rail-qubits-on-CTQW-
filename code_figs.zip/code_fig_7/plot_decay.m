% (1)     (2)     (3)     (4)     (5)     (6)     (7)     (8)     (9)     (10)      (11)	(12)	(13)		
% 00	10      01      00      00      11      10      10      01      01		00		00		00											
% 00	00      00     10      01      00      01      10      10      01      11		20		02		

clc
close all
clear all
fs=30;
set(0,'defaultAxesFontName', 'Times New Roman')
set(0,'defaultTextFontName', 'Times New Roman')
set(0,'DefaultLineLinewidth',2)
set(0,'DefaultAxesFontSize', fs)
set(0,'DefaultTextFontSize', fs)

J=1;
V=-3.5+2*sqrt(3);
U=-3.5-2*sqrt(3);

Gamma_d = J/5000; % dephasing 
%Gamma_d = 0;
Gamma_r = J/5000; % decay
%Gamma_r = 0;

H0_1=diag([0,0,0]);
H0_2=[0 -J;-J 0];
H0_3=0;


H1 = [0              -J;
     -J              0];
 
H2 = [V   -sqrt(2)*J   -sqrt(2)*J;
     -sqrt(2)*J   U   0;
     -sqrt(2)*J   0   U]; 
 
H=blkdiag( H0_1,H0_2,H0_3,H1,H1,H2);
D=length(H);
% define dephasing operators
L_d=zeros(D,D,D);
for i=1:D
    tmp1=zeros(1,i-1);
    tmp2=sqrt(Gamma_d);
    tmp3= zeros(1,D-i);
    L_d(i,:,:)=diag([tmp1,tmp2,tmp3]);
end
% define relaxation operators
L_r=zeros(18,D,D);
L_r(1,1,2)=sqrt(Gamma_r);
L_r(2,1,3)=sqrt(Gamma_r);
L_r(3,1,4)=sqrt(Gamma_r);
L_r(4,1,5)=sqrt(Gamma_r);
L_r(5,3,6)=sqrt(Gamma_r);
L_r(6,2,6)=sqrt(Gamma_r);
L_r(7,5,7)=sqrt(Gamma_r);
L_r(8,2,7)=sqrt(Gamma_r);
L_r(9,2,8)=sqrt(Gamma_r);
L_r(10,4,8)=sqrt(Gamma_r);
L_r(11,3,9)=sqrt(Gamma_r);
L_r(12,4,9)=sqrt(Gamma_r);
L_r(13,3,10)=sqrt(Gamma_r);
L_r(14,5,10)=sqrt(Gamma_r);
L_r(15,4,11)=sqrt(Gamma_r);
L_r(16,5,11)=sqrt(Gamma_r);
L_r(17,4,12)=sqrt(sqrt(2)*Gamma_r);
L_r(18,5,13)=sqrt(sqrt(2)*Gamma_r);
   
psi_tmp=zeros(D,1);
psi1=psi_tmp;
psi1(6)=1;
psi2=psi_tmp;
psi2(7)=1;
psi3=psi_tmp;
psi3(9)=1;
psi4=psi_tmp;
psi4(11)=1;
 
%H=blkdiag(0,H1,H1,H2,Z);


I=eye(13);
M = P_JUST(-1i*H,I) + P_JUST(I,1i*H);
% Loop for dephasing
L_tmp=zeros(D,D);
L_tmp2=zeros(D,D);
for i=1:D
    L_tmp=squeeze(L_d(i,:,:));
    M = M + 1/2*(2*P_JUST(L_tmp,L_tmp')-P_JUST(I,L_tmp'*L_tmp)-P_JUST(L_tmp'*L_tmp,I));
end

for i=1:18
    L_tmp=squeeze(L_r(i,:,:));
    M = M + 1/2*(2*P_JUST(L_tmp,L_tmp')-P_JUST(I,L_tmp'*L_tmp)-P_JUST(L_tmp'*L_tmp,I));
end
%M = M + 1/2*(2*P_JUST(L,L')-P_JUST(I,L'*L)-P_JUST(L'*L,I));

%psi0 = [0;1;0;0;0;0;0;0;0;0;0;0;0];
%psi0 = [1;0;0;0;0;0;0;0;0;0;0;0;0];
%psi0 = [0;0;0;0;0;1;0;0;0;0;0;0;0];

ode_func = @(t, rho) M * rho;

rho = psi1*psi1';
rho_v1 = rho(1:end).';

rho = psi2*psi2';
rho_v2 = rho(1:end).';

rho = psi3*psi3';
rho_v3 = rho(1:end).';

rho = psi4*psi4';
rho_v4 = rho(1:end).';
 t_span = 0:0.001:30*pi; 
 steps=length(t_span);
 options = odeset('RelTol',1e-10,'AbsTol',1e-10,'InitialStep',42061);
 [t1, rho_t1] = ode45(ode_func, t_span, rho_v1,options);
  [t2, rho_t2] = ode45(ode_func, t_span, rho_v2,options);
   [t3, rho_t3] = ode45(ode_func, t_span, rho_v3,options);
    [t4, rho_t4] = ode45(ode_func, t_span, rho_v4,options);
    rho_1000 = squeeze(rho_t1(:,15));
    rho_0010 = squeeze(rho_t1(:,29));
 rho_1010 = squeeze(rho_t1(:,71));
  rho_1001 = squeeze(rho_t2(:,85));
   rho_1100 = squeeze(rho_t2(:,99));
   rho_1000_2=squeeze(rho_t2(:,15));
   rho_0001_2=squeeze(rho_t2(:,57));   
  rho_0110 =  squeeze(rho_t3(:,113));
  
    rho_0101 = squeeze(rho_t4(:,141));
    rho_0200 = squeeze(rho_t4(:,155));
    rho_0002 = squeeze(rho_t4(:,169));
 rho_0001_4=squeeze(rho_t4(:,57));
 rho_0100_4=squeeze(rho_t4(:,43));

% t_span = [0 40*pi];  
% [t, rho] = ode45(ode_func, t_span, rho_0);
% 
% rho=rho';
% [n,m]=size(rho);
% for ni = 1:m
%     rho_1010(ni) = rho(1,ni);
%     rho_1001(ni) = rho(15,ni);
%     rho_1100(ni) = rho(29,ni);
%     rho_0110(ni) = rho(43,ni);
%     rho_0011(ni) = rho(57,ni);
%     rho_0101(ni) = rho(71,ni);
%     rho_0200(ni) = rho(85,ni);
%     rho_0002(ni) = rho(99,ni);
% end

figure(1)
plot(t1/(2*pi), real(rho_1010),'r', 'LineWidth', 2);
% plot(t/(2*pi), real(rho_0101), 'LineWidth', 2);
hold on
plot(t1/(2*pi), real(rho_1000),'b', 'LineWidth', 2);
plot(t1/(2*pi), real(rho_0010), '--g','LineWidth', 2);
xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');
ylabel('Population');
%axis([0 t_total 0 1]);
legend({'$|0;0\rangle_L$', '$|10;00\rangle$','$|00;10\rangle$'}, 'Interpreter', 'latex','location','southeast');
xticks([0, 5, 10, 15,20]); 
xticklabels({'0', '5', '10','15','20'});
legend('boxon'); 
fig = gcf; 
fig.Position(3) = fig.Position(3) * 2;
set(gcf, 'Units', 'inches', 'Position', [1, 1, 8, 4]);  
saveas(gcf,'Decay00.eps','epsc');


figure(2)
plot(t2/(2*pi), real(rho_1001),'r', 'LineWidth', 2);
% plot(t/(2*pi), real(rho_0101), 'LineWidth', 2);
hold on
plot(t2/(2*pi), real(rho_1100),'b', 'LineWidth', 2);
%plot(t4/(2*pi), real(rho_0002), '--g','LineWidth', 2);
xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');
ylabel('Population');
%axis([0 t_total 0 1]);
legend({'$|0;1\rangle_L$', '$|11;00\rangle$'}, 'Interpreter', 'latex','location','southeast');
xticks([0, 5, 10, 15,20]); 
xticklabels({'0', '5', '10','15','20'});
legend('boxon'); 
fig = gcf; 
fig.Position(3) = fig.Position(3) * 2;
set(gcf, 'Units', 'inches', 'Position', [1, 1, 8, 4]);  
saveas(gcf,'Decay01.eps','epsc');

figure(3)
plot(t4/(2*pi), real(rho_0101),'r', 'LineWidth', 2);
% plot(t/(2*pi), real(rho_0101), 'LineWidth', 2);
hold on
plot(t4/(2*pi), real(rho_0200),'b', 'LineWidth', 2);
plot(t4/(2*pi), real(rho_0002), '--g','LineWidth', 2);
xlabel('$t/T_{\rm{CP}}$', 'Interpreter', 'latex');
ylabel('Population');
%axis([0 t_total 0 1]);
legend({'$|1;1\rangle_L$', '$|02;00\rangle$','$|00;02\rangle$'}, 'Interpreter', 'latex','location','southeast');
xticks([0, 5, 10, 15,20]); 
xticklabels({'0', '5', '10','15','20'});
legend('boxon'); 

fig = gcf; 
fig.Position(3) = fig.Position(3) * 2;
set(gcf, 'Units', 'inches', 'Position', [1, 1, 8, 4]);  
saveas(gcf,'Decay11.eps','epsc');

index=[71,85,113,141];
rho_logic = zeros(steps,4,4);
rho_logic(:,1,1) = rho_1010;
rho_logic(:,2,2) = rho_1001;
rho_logic(:,3,3) = rho_0110;
rho_logic(:,4,4) = rho_0101;



% Gamma_d = 2*pi*6; % dephasing rate of excited state |e>
% Omega_e = 2*pi*15; % Rabi frequency of exciting field
% Delta_e = 2*pi*5; % detuning of the |g>-|e> transition
% 
% H = (1/2)*[0              Omega_e;
%              Omega_e       2*Delta_e];% Hamiltonians of atom 
%          
%          
% Psi_g=[1;0];
% Psi_e=[0;1];
% 
% L = sqrt(Gamma_d)*Psi_g*Psi_e';
% I=eye(2);
% M = P_JUST(-1i*H,I) + P_JUST(I,1i*H);
% M = M + 1/2*(2*P_JUST(L,L')-P_JUST(I,L'*L)-P_JUST(L'*L,I));
% 
% N = 1000;
% t_total = 1;
% dt = t_total/N;
% T = 0:dt:t_total;
% 
% psi0 = [1;0];
% rho = psi0*psi0';
% rho_0 = rho(1:end).';
% [W,E] = eig(M);
% e = diag(E);
% u = exp(e*dt);
% U = diag(u);
% 
% rho_ee = 0*T;
% 
% rho_t = rho_0;
% for ni = 1:length(T)
%     rho_t = W * U /W * rho_t;
%     rho_ee(ni) = rho_t(end);
% end
% 
% plot(T, real(rho_ee));
% hold on
% axis([0 t_total 0 1])